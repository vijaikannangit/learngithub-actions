"""
Package Creation in Python.
This Module is developed as a Demo Package for testing python package.
This Module displays Name.
"""

def SayHello(name):
    """
    Displays Name for Package Creation
    """

    print("Hello ... This is a sample code written for creating package in PyPi. I am ", name)
