"""
Functions returns next number for the given argument
"""

def add_one(number):
    """
    Next Number of given arguments.
    Keyword arguments:
    -----------------
    number : number format.   
    Returns:
    --------
    number+1 : Number.
        Returns Next Numbers of the given number.
    """ 
    return number + 1