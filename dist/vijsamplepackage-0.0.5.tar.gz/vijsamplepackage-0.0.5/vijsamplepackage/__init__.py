"""
The specified functions can now be imported in the interpreter session or another executable script.
"""

from .functions import average, power
from .greet import SayHello